Portfolio with three projects (Churn, Walmart, Mental Health). npm install, npm run dev, npm run build. Replace images in public/images/ to update project previews.
